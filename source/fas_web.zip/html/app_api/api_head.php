<html>
<head>
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0;" name="viewport" />
<meta charset="utf-8"> 
<script src="/css/jquery.min.js"></script>
<link href="/css/bootstrap.min.css" rel="stylesheet">
<script src="/css/bootstrap-theme.min.css"></script>
<script src="/css/bootstrap.min.js"></script>
<link rel="stylesheet" href="/css/font-awesome.min.css">
<title>叮咚云端访问</title>
<style>
body,html{
	background:#efefef;
	padding:0px;
	margin:0px;
	overflow-x:hidden;
}
a{ text-decoration:none} 
a:hover,a:link{ text-decoration:none} 
.main{
	margin:10px;
}
.list-group-item a{
	display:block;
}
.label-t{
	margin-bottom:20px;
}
.line{
	height:1px;
	background:#ccc;
}
.btn{
	border-radius: 0px;

}
</style></head>
<body>

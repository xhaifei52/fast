<?php
$data[0]["user"]="user250730";
$data[0]["pass"]="242360";
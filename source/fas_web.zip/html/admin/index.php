<?php
/*
	检测程序是否已经安装
*/
header("location:admin.php");

